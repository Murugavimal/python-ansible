from fastapi import FastAPI


app= FastAPI()

@app.get("/")
def loaduser():
    return{"message": "Working good"}