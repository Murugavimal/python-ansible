


print("Welcome to thetraining ... ... . . . . . !")

name = "sarva"

print(f" good to see {name}") 

