a = int(input("Enter Value of A: "))
b= int(input("Enter the Value of B: "))

print(f"Result = {a+b}") 