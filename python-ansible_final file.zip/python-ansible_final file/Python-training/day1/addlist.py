a = [10, 12, 131, 41, 5] 

result = 0
for i in a: 
    result = result + i
print(result)