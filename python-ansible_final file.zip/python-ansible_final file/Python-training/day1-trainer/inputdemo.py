
data=input('Enter your name: ')

print (f"Welcome : {data}")