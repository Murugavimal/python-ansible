
a= int(input('Enter the Value of a: '))
b= int(input('Enter the Value of b: '))

c=a+b
print(f"The addition is: {c} ")